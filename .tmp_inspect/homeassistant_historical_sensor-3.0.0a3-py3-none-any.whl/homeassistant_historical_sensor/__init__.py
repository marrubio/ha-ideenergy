# Copyright (C) 2021-2023 Luis López <luis@cuarentaydos.com>
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301,
# USA.


from .sensor import HistoricalSensor, PollUpdateMixin
from .timemachine import (
    HistoricalState,
    group_by_interval,
    hass_check_version,
    hass_get_last_statistic,
)

hass_check_version()

__all__ = [
    "HistoricalSensor",
    "HistoricalState",
    "PollUpdateMixin",
    "group_by_interval",
    "hass_get_last_statistic",
]
